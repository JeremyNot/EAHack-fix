package me.alpha432.stay;

import me.alpha432.stay.event.events.Render3DEvent;
import me.alpha432.stay.features.gui.font.CustomFont;
import me.alpha432.stay.manager.*;
import me.alpha432.stay.util.Enemy;
import me.alpha432.stay.util.IconUtil;
import me.alpha432.stay.util.Title;
import net.minecraft.util.Util;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

import java.awt.*;
import java.io.InputStream;
import java.nio.ByteBuffer;

@Mod(
        modid = Stay.MOD_ID,
        name = Stay.MOD_NAME,
        version = Stay.VERSION
)
public class Stay {
    public static final String MOD_ID = "stay";
    public static final String MOD_NAME = "stay";
    public static final String VERSION = "1.12.2";
    public static final String ID = "0.4.3";
    public static final Logger LOGGER = LogManager.getLogger("stay");
    public static TimerManager timerManager;
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static CustomFont fontRenderer;
    public static Render3DEvent render3DEvent;
    public static Enemy enemy;
    public static final EventBus EVENT_BUS = new EventBus();

    public static MenuFont MENU_FONT_MANAGER= new MenuFont();
    public static GuiFont GUI_FONT_MANAGER= new GuiFont();
    public static DonatorFont DONATOR_FONT_MANAGER= new DonatorFont();
    public static SongManager SONG_MANAGER= new SongManager();
    @Mod.Instance
    public static Stay INSTANCE;
    private static boolean unloaded;

    static {
        unloaded = false;
    }
    @Mod.EventHandler
    public void preinit(FMLPreInitializationEvent event) {
        System.out.println("Mod preinit");
    }



    @Mod.EventHandler
    public void postinit(FMLPostInitializationEvent event) {
        System.out.println("Mod postinit");
    }
    public static void load() {
        LOGGER.info("loading stay");

        unloaded = false;
        if (reloadManager != null) {
            reloadManager.unload();
            reloadManager = null;
        }
        textManager = new TextManager();
        commandManager = new CommandManager();
        friendManager = new FriendManager();
        moduleManager = new ModuleManager();
        rotationManager = new RotationManager();
        packetManager = new PacketManager();
        eventManager = new EventManager();
        speedManager = new SpeedManager();
        potionManager = new PotionManager();
        inventoryManager = new InventoryManager();
        serverManager = new ServerManager();
        fileManager = new FileManager();
        colorManager = new ColorManager();
        positionManager = new PositionManager();
        configManager = new ConfigManager();
        holeManager = new HoleManager();
        LOGGER.info("Managers loaded.");
        moduleManager.init();
        LOGGER.info("Modules loaded.");
        configManager.init();
        eventManager.init();
        LOGGER.info("EventManager loaded.");
        textManager.init(true);
        moduleManager.onLoad();
        LOGGER.info("stay successfully loaded!\n");
    }

    public static void unload(boolean unload) {
        LOGGER.info("unloading stay");
        if (unload) {
            reloadManager = new ReloadManager();
            reloadManager.init(commandManager != null ? commandManager.getPrefix() : ".");
        }
        Stay.onUnload();
        eventManager = null;
        friendManager = null;
        speedManager = null;
        holeManager = null;
        positionManager = null;
        rotationManager = null;
        configManager = null;
        commandManager = null;
        colorManager = null;
        serverManager = null;
        fileManager = null;
        potionManager = null;
        inventoryManager = null;
        moduleManager = null;
        textManager = null;
        LOGGER.info("stay unloaded!\n");
    }

    public static void reload() {
        Stay.unload(false);
        Stay.load();
    }

    public static void onUnload() {
        if (!unloaded) {
            eventManager.onUnload();
            moduleManager.onUnload();
            configManager.saveConfig(Stay.configManager.config.replaceFirst("EAHack/", ""));
            moduleManager.onUnloadPost();
            unloaded = true;
        }
    }


    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new Title());
        Stay.load();
    }
}

