package me.alpha432.stay.util;

import net.minecraft.client.Minecraft;

public interface MinecraftInstance {
    public static final Minecraft mc = Minecraft.getMinecraft();
}
