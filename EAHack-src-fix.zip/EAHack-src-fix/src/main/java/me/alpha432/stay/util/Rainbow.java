package me.alpha432.stay.util;

import java.awt.*;

public class Rainbow {

    public static Color getColour() {
        return Colour.fromHSB((System.currentTimeMillis() % (360 * 32)) / (360f * 32), 1, 1);
    }

}
