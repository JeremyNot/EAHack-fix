package me.alpha432.stay.event.events;

import me.alpha432.stay.event.EventStage;

public class UpdateWalkingPlayerEvent
        extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}

